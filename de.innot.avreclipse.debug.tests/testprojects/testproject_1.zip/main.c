/*
 * main.c
 *
 *  Created on: 06.12.2008
 *      Author: Thomas
 */

#include <avr/io.h>

int main(void) {

	volatile uint8_t counter = 0;

	while(1) {
		counter++;
		__asm("nop");
	}
}
